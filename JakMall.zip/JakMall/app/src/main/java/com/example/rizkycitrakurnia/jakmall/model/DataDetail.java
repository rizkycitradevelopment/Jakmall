package com.example.rizkycitrakurnia.jakmall.model;

public class DataDetail {

    public String id;
    public String text;
}
