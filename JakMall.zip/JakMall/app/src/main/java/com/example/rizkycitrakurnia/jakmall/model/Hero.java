package com.example.rizkycitrakurnia.jakmall.model;

public class Hero {

    private String name;


    public Hero(String name) {
        this.name = name;

    }

    public String getName() {
        return name;
    }


}
